import unittest
import test


class testquestions(unittest.TestCase):

    def divide(self, integer1, integer2):
        x = integer1 / integer2
        return x

    def almost_palindrome(self, string):
        return 0

    def multiply_Strings(self, string1, string2):
        return 99

    def Super_Palindrome(self, array1):
        return array1

    def trueorfalse(self, integer):
        return True

    def find_gcd(self, integer1, integer2):
        return 99

    def average_String(self, string):
        array1=[]
        return array1  # returns an array

    def potential(self, string):
        m = ''
        return m

    def series(self, interger):
        array=[]
        return array  # returns an array

    def filename(self, string):
        m = ''
        return m

    def disarium(self, integer):
        return False

    def special(self, integer):
        return False

    def equalarr(self, array1, array2, integer1, integer2):
        return False

    def prime(self, integer):
        return array  # returns an array

    def automorphic(self, integer):
        return False

    def alphabetical(self, string):
        return False

    def arrtostr(self, character):
        m = ''
        return m

    def specialarr(self, array, integer):
        return False

    def series1(self, integer):
        return 0

    def anagram(self, string1, string2):
        return False

    def netbill(self, double1):
        return 0.0

    def parcel(self, integer):
        return 0

    def vowels(self, string, integer):
        m = ''
        return m

    def maxfreq(self, string):
        ch = ''
        return ch  # returns a character

    def lastindex(self, string):
        return 0

    def dashes(self, integer):
        string = ""
        return string

    def permutations(self, string):
        string1 = []
        return string1  # returns an array

    def repeat(self, string):
        ch = ''
        return ch  # returns a character

    def singledigit(self, integer):
        return 0

    def happy(self, integer):
        return False

    def series2(self, integer):
        return 0

    def missingnum(self, array, integer):
        return 0

    def apocalyptic(self, integer):
        return False

    def alternate(self, array, integer):
        return 0

    def sorting(self, array, integer):
        return False

    def encrypt(self, string):
        a = ""
        return a  # returns a string

    def diagonalmatrix(self, array, integer):
        return False

    def armstrong(self, integer):
        return False

    def kempner(self, integer):
        return 0

    def rearrange(self, character, array):
        string = ""
        return string  # returns a string

    def ascending(self, integer):
        return False

    def descending(self, integer):
        return False

    def alphasort(self, array):
        array1 = []
        return array1  # returns an array

    def doubleletter(self, string):
        return 0

    def piglatin(self, string):
        a = ""
        return a

    def semiprime(self, integer):
        return False

    def balanced(self, integer):
        return False

    def even(self, array):
        return False

    def diagonals(self, array, integer):
        return 0

    def reverse(self, string):
        a = ""
        return a

    def triangular(self, integer):
        a = []
        return a  # returns an array
