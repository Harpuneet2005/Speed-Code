
import unittest

from Questions import TestStringMethods

class TestPyUnitReport(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_01_something(self):
        pass

if __name__ == '__main__':
    unittest.main()
